# EmoTracker Pack for Illusion of Gaia : Randomizer

Includes following :

* Item Tracker :
  * You can count Red Jewels, Herbs, Hieroglyphs, Crystal Balls, Rama/Hope Statues obtained
  * You can note Hieroglyphs order
  * You can note needed Mystic Statues
  * You can note used/given items for many of them

* Map Tracker :
  * Item tracking depending on pre-obtained items/abilities
  * Dark Spaces tracking depending on pre-obtained items/abilities
    * Off : No Dark Spaces tracking displayed
    * Dungeons : Only display Dungeons Dark Spaces tracking
    * All : Display all Dark Spaces tracking

